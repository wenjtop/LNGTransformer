from .utils import clever_format
from .profile import profile, profile_origin

import torch
default_dtype = torch.float64